﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} número ", "Entrada de Dados");

                if (auxiliar == "")
                {
                    break;
                }

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!!");
                    i--;
                }
                else
                {
                    saida = auxiliar + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
            Array.Reverse(vetor); //inverter
            auxiliar = "";
            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            lista.Remove("Otávio");
            foreach (string item in lista)
            {
                MessageBox.Show(item);

            }
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double media = 0;
            double teste=0;
            string notas1;

            double[,] medias = new double[20, 3];
            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    notas1 = Interaction.InputBox($"Aluno {aluno + 1} nota {nota + 1}");
                    if(!double.TryParse(notas1, out teste))
                    {
                        MessageBox.Show("Tem que ser um número");
                        nota--;
                    }
                    else if (Convert.ToDouble(notas1) < 0 || Convert.ToDouble(notas1) > 10)
                    {
                        MessageBox.Show("O número tem que ser entre 0 a 10");
                        nota--;
                    }
                    else
                        medias[aluno, nota] = Convert.ToDouble(notas1);

                }


            }
            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    media = media + medias[aluno, nota];
                }
                MessageBox.Show($"Aluno {aluno + 1}: média: {media / 3} ");
                media = 0;
            }

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            frmEx4 objEx4 = new frmEx4();
            objEx4.Show();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            frmEx5 objEx5 = new frmEx5();
            objEx5.Show();
        }
    }
}
