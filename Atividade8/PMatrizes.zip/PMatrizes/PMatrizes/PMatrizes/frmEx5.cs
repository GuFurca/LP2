﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class frmEx5 : Form
    {
        public frmEx5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliar, maisculo;
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'C', 'B', 'D', 'E' };
            char[,] alunos = new char[3, 10];
            for (int j = 0; j < 3; j++)
            {
                for (int i = 0; i < 10; i++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {i + 1} do aluno {j + 1}", "Entrada de dados");
                    maisculo = auxiliar.ToUpper();
                    if (maisculo.Length == 1)
                    {
                        char charmaisculo = Convert.ToChar(maisculo);
                        if (charmaisculo == 'A' || charmaisculo == 'B' || charmaisculo == 'C' || charmaisculo == 'D' || charmaisculo == 'E')
                        {
                            alunos[j, i] = charmaisculo;
                        }
                        else
                        {
                            MessageBox.Show("Resposta inválida. Por favor, insira A, B, C, D ou E.");
                            i--;
                        }

                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida");
                        i--;
                    }
                }
            }
                for (int cont = 0; cont < 3; cont++)
                {
                    for (int cont2 = 0; cont2 < 10; cont2++)
                    {
                        if (gabarito[cont2] == alunos[cont, cont2])
                        {
                            LstboxNotas.Items.Add($"O aluno {cont + 1} acertou a questão {cont2 + 1}: era {gabarito[cont2]}, escolheu {alunos[cont, cont2]}");
                        }
                        else
                        {
                            LstboxNotas.Items.Add($"O aluno {cont + 1} errou a questão {cont2 + 1}: era {gabarito[cont2]}, escolheu {alunos[cont, cont2]}");
                        }
                    }
                }
            
        }

    }
}
