﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;       

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        float valorA, valorB, valorC;
        public Form1()
        {
            InitializeComponent();
        }

 

        private void txtValorB_Validating(object sender, CancelEventArgs e)
        {
            if (!float.TryParse(txtValorB.Text, out valorB))
            {
                MessageBox.Show("Valor B inválido");
                e.Cancel = true;
            }
            if (valorB == 0)
            {
                MessageBox.Show("Valor B inválido");
                e.Cancel = true;
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((valorA < valorB + valorC) && (valorA > Math.Abs(valorB - valorC)) && (valorB < valorA + valorC) && (valorB > Math.Abs(valorC - valorA)) && (valorC < valorA + valorB) && (valorC > Math.Abs(valorB - valorA)))
            {
                if (valorA == valorB && valorC == valorA)
                {
                    MessageBox.Show("Triângulo, Isósceles.");
                }
                else if (valorB == valorA || valorA == valorC || valorB == valorC)
                {
                    MessageBox.Show("Triângulo, Equilátero.");
                }
                else if (valorB != valorA && valorA != valorC && valorB != valorC)
                {
                    MessageBox.Show("Triângulo, Escaleno.");
                }
                else
                {
                    MessageBox.Show("Triângulo, mas não identificado.");
                }

            }
            else
            {
                MessageBox.Show("Não pode formar um triângulo");  
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtValorC_Validating(object sender, CancelEventArgs e)
        {
            if (!float.TryParse(txtValorC.Text, out valorC))
            {
                MessageBox.Show("Valor C inválido");
                e.Cancel = true;
            }
            if (valorC == 0)
            {
                MessageBox.Show("Valor C inválido");
                e.Cancel = true;
            }
        }


        private void txtValorA_Validating(object sender, CancelEventArgs e)
        {
            if (!float.TryParse(txtValorA.Text, out valorA))
            {
                MessageBox.Show("Valor A inválido");
                e.Cancel = true;
            }
            if (valorA == 0)
            {
                MessageBox.Show("Valor A inválido");
                e.Cancel = true;
            }
        }
    }
}
