﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv7
{
    public partial class frmEx3 : Form
    {
        public frmEx3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string Stringona = txtPalavra.Text;
            Stringona = Stringona.Replace(" ", "");
            Stringona = Stringona.ToUpper();
            string StringonaInvertida = new string (Stringona.Reverse().ToArray());
            if (Stringona == StringonaInvertida)
            {
                MessageBox.Show($"É um palíndromo: {StringonaInvertida}");
            }
            else
            {
                MessageBox.Show($"Não é um palíndromo: {StringonaInvertida}");
            }
        }
    }
}
