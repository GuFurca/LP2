﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv7
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            if (100 < rchtxtFrase.Text.Length)
            {
                MessageBox.Show("Tem mais de 100 letras (CONTANDO ESPAÇOS)");
            }
            else
            {
                for (var i = 0; i < rchtxtFrase.Text.Length; i++)
                {
                    if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                    {
                        posicao = posicao + 1;

                    }

                }
                if (posicao == 0)
                {
                    MessageBox.Show("Não tem nenhum espaço");
                }
                else
                {
                    MessageBox.Show($"Espaços em branco: {posicao}");
                }
            }
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            if (100 < rchtxtFrase.Text.Length)
            {
                MessageBox.Show("Tem mais de 100 letras (CONTANDO ESPAÇOS)");
            }
            else
            {
                for (var i = 0; i < rchtxtFrase.Text.Length; i++)
                {
                    if (rchtxtFrase.Text[i] == 'R' || rchtxtFrase.Text[i] == 'r')
                    {
                        posicao = posicao + 1;

                    }

                }
                if (posicao == 0)
                {
                    MessageBox.Show("Não tem nenhum R");
                }
                else
                {
                    MessageBox.Show($"Número de R: {posicao}");
                }
            }
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            string maiusculo=rchtxtFrase.Text.ToUpper();
            int posicao = 0;
            //if (100 < rchtxtFrase.Text.Length)
            //{
            //    MessageBox.Show("Tem mais de 100 letras (CONTANDO ESPAÇOS)");
            //}
            //else
            //{
                for (var i = 0; i < rchtxtFrase.Text.Length - 1; i++)
                {
                    if ((maiusculo[i] == maiusculo[i + 1]))
                    {
                        posicao = posicao + 1;

                    }

                }
                if (posicao == 0)
                {
                    MessageBox.Show("Não tem nenhum par de letras");
                }
                else
                {
                    MessageBox.Show($"Número de pares: {posicao}");
                }
            //}
        }
    }
}