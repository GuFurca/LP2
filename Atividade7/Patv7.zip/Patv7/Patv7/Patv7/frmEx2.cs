﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv7
{
    public partial class frmEx2 : Form
    {
        public frmEx2()
        {
            InitializeComponent();
        }

        private void txtN_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtN.Text, out int numero))
            {
                MessageBox.Show("Tem que ser um número inteiro!!!");
                txtN.Focus();
            }
            else if (numero == 0)
            {
                MessageBox.Show("Não pode ser 0, usuário malvado!");
                txtN.Focus();
                
            }
        }

        private void btnH_Click(object sender, EventArgs e)
        {
            double H=0;
            double i;
            for (i = 0; i < Convert.ToDouble(txtN.Text); i++)
            {
                // MessageBox.Show("Teste");
                H += 1.0 / (i + 1);
            }
            H=Math.Round(H,2);
            MessageBox.Show($"O número H vai ser: {H}");
        }
    }
}
