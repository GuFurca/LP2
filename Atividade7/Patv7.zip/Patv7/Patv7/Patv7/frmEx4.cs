﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv7
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double SalBruto, A, B=0, C=0, D=0;
            A = Convert.ToDouble(txtSalario.Text);
            if (Convert.ToDouble(txtProducao.Text) >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }
            else if (Convert.ToDouble(txtProducao.Text) >= 120)
            {
                B = 1;
                C = 1;
            }
            else if (Convert.ToDouble(txtProducao.Text) >= 100)
            {
                B = 1;
            }
            SalBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D)+Convert.ToDouble(txtGratificacao.Text);
            if ((SalBruto > 7000) && ((Convert.ToDouble(txtProducao.Text) < 150) || (Convert.ToDouble(txtGratificacao.Text) == 0)))
            {
                SalBruto = 7000;
            }
            SalBruto = Math.Round(SalBruto, 2);
            txtSalarioBruto.Text = SalBruto.ToString();
        }

        private void txtNome_Validating(object sender, CancelEventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Coloque o seu nome!");
                txtNome.Focus();
            }
        }

        private void txtMatricula_Validating(object sender, CancelEventArgs e)
        {
            if (txtMatricula.Text == "")
            {
                MessageBox.Show("Coloque a sua matricula!");
                txtMatricula.Focus();
            }
        }

        private void txtProducao_Validating(object sender, CancelEventArgs e)
        {
            if (txtProducao.Text == "")
            {
                MessageBox.Show("Coloque o seu tempo de produção!");
                txtProducao.Focus();
            }
            else if (!double.TryParse(txtProducao.Text, out double producao)||producao<0)
            {
                MessageBox.Show("Tem que ser um número maior ou igual a zero");
                txtProducao.Focus();
            }
        }

        private void txtSalario_Validating(object sender, CancelEventArgs e)
        {
            if (txtSalario.Text == "")
            {
                MessageBox.Show("Coloque o seu salário!");
                txtSalario.Focus();
            }
            else if ((!double.TryParse(txtSalario.Text, out double salario)) || (salario < 1412))
            {
                MessageBox.Show("O salário líquido mínimo no Brasil é cerca de R$ 1.412,00");
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_Validating(object sender, CancelEventArgs e)
        {
            if (txtGratificacao.Text == "")
            {
                MessageBox.Show("Coloque a sua gratificação! Se não tiver coloca 0");
                txtGratificacao.Focus();
            }
            else if (!double.TryParse(txtGratificacao.Text, out double producao) || producao < 0)
            {
                MessageBox.Show("Tem que ser um número maior ou igual a zero");
                txtGratificacao.Focus();
            }
        }
    }
}
