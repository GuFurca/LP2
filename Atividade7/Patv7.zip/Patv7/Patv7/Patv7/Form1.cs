﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void altSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx1>().Count() > 0)
            {
                MessageBox.Show("Esse forms já existe!!!");
                Application.OpenForms["frmEx1"].Activate();
            }
            else
            {
                frmEx1 obj1 = new frmEx1();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
            
            
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx2>().Count() > 0)
            {
                MessageBox.Show("Esse forms já existe!!!");
                Application.OpenForms["frmEx2"].BringToFront();
            }
            else
            {
                frmEx2 obj2 = new frmEx2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx3>().Count() > 0)
            {
                MessageBox.Show("Esse forms já existe!!!");
                Application.OpenForms["frmEx3"].BringToFront();
            }
            else
            {
                frmEx3 obj3 = new frmEx3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx4>().Count() > 0)
            {
                MessageBox.Show("Esse forms já existe!!!");
                Application.OpenForms["frmEx4"].BringToFront();
            }
            else
            {
                frmEx4 obj4 = new frmEx4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }
    }
}
