﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxTotalVendas.Items.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] TotalVendas = new double[2, 4];
            double TotalSemana, TotalMes, Total = 0;
            int i = 0, j = 0;
            string auxiliar = "";
            for (i = 0; i < 2; i++)
            {
                TotalMes = 0;
                for (j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o total de vendas da semana {j + 1} do mês {i + 1}: ", "Entrada de Dados");
                    if (!double.TryParse(auxiliar, out TotalVendas[i, j]))
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }
                    else if (TotalVendas[i, j] < 0)
                    {
                        MessageBox.Show("Valor deve ser acima de 0");
                        j--;
                    }
                    else
                    {
                        TotalSemana = Convert.ToDouble(auxiliar);
                        lstbxTotalVendas.Items.Add($"Total do mês: {i + 1} Semana: {j + 1}   " + TotalSemana.ToString("F2"));
                        TotalMes += TotalSemana;
                        if (j == 3)
                        {
                            lstbxTotalVendas.Items.Add($">> Total Mês: " + TotalMes.ToString("F2"));
                        }
                       
                    }

                }
                Total += TotalMes;
                
            }
            lstbxTotalVendas.Items.Add($">> Total Geral: " + Total.ToString("F2"));
        }
    }
}
